<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');
//Build: 230211
$config['version'] = "1.0";
