<?php

$config['meeting_with'] = array(
    'student' => lang('student'),
    'staff' => lang('staff'),
);